import PublicNav from "@/components/layout/PublicNav";
import Footer from "@/components/layout/Footer";
import HomePage from "@/components/pages/HomePage";

export default function RootPage() {
  return (
    <>
      <PublicNav />
      <main>
        <HomePage />
      </main>
      <Footer />
    </>
  );
}
